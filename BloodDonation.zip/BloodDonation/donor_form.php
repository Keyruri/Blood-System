<?php
if (isset($_REQUEST["email"])) {
    //get our form data
    $donation_time = $_REQUEST["donation_time"];
    $date = $_REQUEST["date"];
    $problem = $_REQUEST["problem"];
    $id_number = $_REQUEST["id_number"];
    $blood_group = $_REQUEST["blood_group"];
    $dob = $_REQUEST["dob"];
    $gender = $_REQUEST["gender"];
    $concent = $_REQUEST["concent"];
    $parent_number = $_REQUEST["parent_number"];
    $donor_number = $_REQUEST["donor_number"];
    $email = $_REQUEST["email"];
    $location = $_REQUEST["location"];
    $hospital = $_REQUEST["hospital"];
    $precondition = $_REQUEST["precondition"];
    $accept = $_REQUEST["accept"];



    require_once 'connect.php';
    //create sql statement
    $sql = "insert into donor_information (id,donation_time ,date,problem,id_number,blood_group,dob,gender,concent,parent_number,donor_number,email,location,hospital,precondition,accept) 
value (null,'$donation_time','$date','$problem','$id_number','$blood_group','$dob','$gender','$concent','$parent_number','$donor_number','$email','$location','$hospital','$precondition','$accept')";

    if (mysqli_query($con, $sql)) {
        echo "<script> alert('Submitted Successfully')</script>";
        setcookie('message', "Information Updated successfully", time()+3);
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($con);
    }

    mysqli_close($con);
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Donor Form</title>
    <link rel="stylesheet" href="css/bootstrap1.min.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">



    <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="script_file.js" type="text/javascript"></script>

    <link rel="stylesheet" href="css/tooplate-style.css">

    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>








</head>
<body>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-6">
            <h3>BLOOD DONATION APPLICATION FORM</h3>
            <form class="shadow-sm" action="donor_form.php" method="post">

                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="donation_time" value="first">First Time Donor
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="donation_time" value="repeat">Repeat Donor
                    </label>
                </div>
                <div>
                    <label>Donation Date</label>
                    <input type="date" name="date">
                </div><br>
                <label> For Repeat Donor</label><br>
                Did you encounter any problems when donating?<br>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="problem" value="yes">yes
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="problem" value="no">No
                    </label>
                </div>
                <div class="form-group">
                    <label>ID CARD NUMBER</label>
                    <input type="number" class="form-control" name="id_number">
                </div>
                <div class="form-group">
                    <label for="sel1">Select your Blood Group:</label>
                    <select class="form-control" name="blood_group">
                        <option VALUE="A">A</option>
                        <option value="B">B</option>
                        <option value="O">O</option>
                        <option value="AB">AB</option>
                    </select>
                </div>
                <hr>
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" class="form-control" name="dob">
                </div>
                <label>Gender</label>
                <div class="form-check-inline">

                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender" value="male">Male
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender" value="female">Female
                    </label>
                </div>
                <div class="form-check-inline disabled">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="gender">Other
                    </label>
                </div>
                <label>If you are between ages 14yrs and 17yrs do you have parents or guardian consent</label>
                <div class="form-check-inline">

                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="concent" value="yes">Yes
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="concent" value="no">No <br>
                    </label>
                </div>
                <div class="form-group">
                    <label>Parents/Guardian phone number</label>
                    <input type="number" class="form-control" name="parent_number">
                </div>
                <div class="form-group">
                    <label>Your phone number</label>
                    <input type="number" class="form-control" name="donor_number">
                </div>
                <div class="form-group">
                    <label>your Email Address</label>
                    <input type="email" class="form-control" name="email">
                </div>
                <div class="form-group">
                    <label>Your Location eg Thika, Nairobi</label>
                    <input type="text" class="form-control" name="location">
                </div>
                <div class="form-group">
                    <label>Nearest Public Hospital Around You</label>
                    <input type="text" class="form-control" name="hospital">
                </div>
                <label>Any Pre-existing Condition?</label>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="precondition" value="yes">Yes
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="precondition" value="no">No
                    </label>
                </div><br>
                I here by declare i have given correct details..
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="accept" value="yes">Yes
                    </label>
                </div>

                <button class="btn btn-block btn-danger"> Submit</button>
            </form>
        </div>
    </div>
</div>
<footer data-stellar-background-ratio="5">
    <div class="container">
        <div class="row">

            <div class="col-md-4 col-sm-4">
                <div class="footer-thumb">
                    <h4 class="wow fadeInUp" data-wow-delay="0.4s">Contact Info</h4>
                    <p>We open everyday even during emergency times except for Sundays. Don't hesitate to contact us.</p>
                    <div class="contact-info">
                        <p><i class="fa fa-phone"></i> +254 704724790</p>
                        <p><i class="fa fa-envelope-o"></i> <a href="#">mathewkeyruri@gmail.com</a></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-4">
                <div class="footer-thumb">
                    <div class="opening-hours">
                        <h4 class="wow fadeInUp" data-wow-delay="0.4s">Opening Hours</h4>
                        <p>Monday - Friday <span>06:00 AM - 10:00 PM</span></p>
                        <p>Saturday <span>09:00 AM - 08:00 PM</span></p>
                        <p>Sunday <span>Closed</span></p>
                    </div>
                    <ul class="social-icon">
                        <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                        <li><a href="#" class="fa fa-twitter"></a></li>
                        <li><a href="#" class="fa fa-instagram"></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 border-top">
                <div class="col-md-4 col-sm-6">
                    <div class="copyright-text">

                    </div>

                    <div class="col-md-2 col-sm-2 text-align-center">
                        <div class="angle-up-btn" style="padding-left: 1000px;">
                            <a href="#top" class="smoothScroll wow fadeInUp" data-wow-delay="1.2s"><i class="fa fa-angle-up"></i></a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</footer>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
