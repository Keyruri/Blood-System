<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "bloodmanagement") or die("Connection Error: " . mysqli_error($conn));

$email = $_SESSION['email'];


if (count($_POST) > 0) {
    $result = mysqli_query($conn, "SELECT *from signup WHERE email = '$email'");
    foreach ($result as $key => $row) {
        $id = $row['id'];
    }
    if ($_POST["currentPassword"] == $row["password"]) {
        mysqli_query($conn, "UPDATE signup set password='" . $_POST["newPassword"] . "' WHERE id= $id");
        $message = "Password Changed";
    } else
        $message = "Current Password is not correct";
}
?>
<html>
<head>
    <title>Change Password</title>

    <link rel="stylesheet" type="text/css" href="css/bootstrap1.min.css">
    <script>
        function validatePassword() {
            var currentPassword, newPassword, confirmPassword, output = true;

            currentPassword = document.frmChange.currentPassword;
            newPassword = document.frmChange.newPassword;
            confirmPassword = document.frmChange.confirmPassword;

            if (!currentPassword.value) {
                currentPassword.focus();
                document.getElementById("currentPassword").innerHTML = "required";
                output = false;
            } else if (!newPassword.value) {
                newPassword.focus();
                document.getElementById("newPassword").innerHTML = "required";
                output = false;
            } else if (!confirmPassword.value) {
                confirmPassword.focus();
                document.getElementById("confirmPassword").innerHTML = "required";
                output = false;
            }
            if (newPassword.value != confirmPassword.value) {
                newPassword.value = "";
                confirmPassword.value = "";
                newPassword.focus();
                document.getElementById("confirmPassword").innerHTML = "not same";
                output = false;
            }
            return output;
        }
    </script>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-5">
            <form class="shadow-sm" name="frmChange" method="post" action=""
                  onSubmit="return validatePassword()">
                <div style="width: 500px;">
                    <div class="message"><?php if (isset($message)) {
                            echo $message;
                        } ?></div>


                    <h4>Change Password</h4>

                    <div class="form-group">

                        <label>Current Password</label>
                        <input type="password"
                               name="currentPassword" class="form-control"
                                id="currentPassword" class="required">
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="newPassword"
                               class="txtField form-control"/><span id="newPassword"
                                                                    class="required"></span>
                    </div>
                    <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirmPassword"
                           class="form-control" id="confirmPassword"
                                                   class="required">
                    </div>

                    <input type="submit" name="submit"
                           value="Submit" class="btnSubmit btn btn-secondary btn-block"><br>


                    <a href="userdashboard.php"><input type="button" name=""
                                                       value="Back" class="btnSubmit btn btn-block btn-danger"></a>

                </div>
        </div>

        </form>
    </div>
</div>
</body>
</html>