<?

class DB
{
	public $host = "localhost";
	public $user = "root";
	public $pass = "";
	public $db = "bloodmanagement";
	public $con;
	//include_once ("connect.php");
	public function __construct()
	{
		$this->con = new mysqli($this->host, $this->user, $this->pass, $this->db);
	}


	public function insertdata()
	{

		if (isset($_POST['submit'])) {
			$name = $_POST['name'];
			$gender = $_POST['gender'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$dob = $_POST['dob'];
			$role = $_POST['role'];

			$sql = "insert into signup (name,gender,email,password,dob,role) value 
			('$name','$gender','$email','$password','$dob', $role)";
            $res = $this->con->query($sql);
            if(!$test=mysql_query($res)) die(mysql_error());
			// if ($res) {
            //     echo "success";
			// 	// header('Location:adminview.php');

			// } else{
            //     echo "Error";
            // }
		}
    }
    
}

?>