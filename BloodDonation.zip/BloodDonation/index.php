<?php

class DB
{
	public $host = "localhost";
	public $user = "root";
	public $pass = "";
	public $db = "bloodmanagement";
	public $con;
	//include_once ("connect.php");
	public function __construct()
	{
		$this->con = new mysqli($this->host, $this->user, $this->pass, $this->db);
	}


	public function insertdata()
	{

		if (isset($_POST['submit'])) {
			$name = $_POST['name'];
			$gender = $_POST['gender'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$dob = $_POST['dob'];
			$role = $_POST['role'];

			$sql = "insert into signup (name,gender,email,password,dob,role) value 
			('$name','$gender','$email','$password','$dob', $role)";
			$res = $this->con->query($sql);
			if ($res) {
				echo "success";
				// header('Location:adminview.php');

			}
		}
	}

	public function login()
	{
		SESSION_START();
		if (isset($_POST['submit1'])) {
			$email = $_POST['email'];
			$password = $_POST['password'];

			$sql = "select * from signup where email='$email' and password='$password'";
			$nums = $this->con->query($sql);


			if (mysqli_num_rows($nums) > 0) {
				$_SESSION['email'] = $email;
				while ($check = mysqli_fetch_array($nums)) {


					if ($check['role'] == 1) {
						//echo "Success";
						header("Location:userdashboard1.php");
					}
					elseif ($check['role'] == 2 ){
                        header("Location:../BloodDonation/Donation/donation_details.php");
                    }
					else {
						header("location:../BloodDonation/admin/admindashboard.php");
						// echo "Not";
					}
				}
			}
		}
	}
}
$obj = new DB;
$obj->insertdata();

$obj1 = new DB;
$obj1->login();


?>

<!DOCTYPE html>
<html lang="en">

<head>

	<title>Web Portal on Blood Donation System.</title>

	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="Tooplate">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">



	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>


	<script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
	<script src="script_file.js" type="text/javascript"></script>

	<link rel="stylesheet" href="css/tooplate-style.css">

	<script src="https://code.jquery.com/jquery-3.2.1.js"></script>

	<style type="text/css">
		.error_form {
			padding-bottom: 5px;
		}


		.cards {
			width: 100%;
			display: flex;
			display: -webkit-flex;
			justify-content: center;
			-webkit-justify-content: center;
			max-width: 1200px;
		}

		.card--1 .card__img,
		.card--1 .card__img--hover {
			background-image: url('images/nurse.jpg');
		}

		.card--2 .card__img,
		.card--2 .card__img--hover {
			background-image: url('images/Mathew.jpg');
		}

		.card--3 .card__img,
		.card--3 .card__img--hover {
			background-image: url('images/doctor2.jpg');
		}

		.card--4 .card__img,
		.card--4 .card__img--hover {
			background-image: url('images/doctor3.jpg');
		}

		.card--5 .card__img,
		.card--5 .card__img--hover {
			background-image: url('images/doctor4.jpg');
		}

		.card__like {
			width: 18px;
		}

		.card__clock {
			width: 15px;
			vertical-align: middle;
			fill: #AD7D52;
		}

		.card__time {
			font-size: 12px;
			color: #AD7D52;
			vertical-align: middle;
			margin-left: 5px;
		}

		.card__clock-info {
			float: right;
		}

		.card__img {
			visibility: hidden;
			background-size: cover;
			background-position: center;
			background-repeat: no-repeat;
			width: 100%;
			height: 235px;
			border-top-left-radius: 12px;
			border-top-right-radius: 12px;
		}

		.card__info-hover {
			position: absolute;
			padding: 16px;
			width: 100%;
			opacity: 0;
			top: 0;
		}

		.card__img--hover {
			transition: 0.2s all ease-out;
			background-size: cover;
			background-position: center;
			background-repeat: no-repeat;
			width: 100%;
			position: absolute;
			height: 235px;
			border-top-left-radius: 12px;
			border-top-right-radius: 12px;
			top: 0;
		}

		.card {
			margin-right: 30px;
			transition: all .4s cubic-bezier(0.175, 0.885, 0, 1);
			background-color: #fff;
			width: 33.3%;
			position: relative;
			border-radius: 12px;
			overflow: hidden;
			box-shadow: 0px 13px 10px -7px rgba(0, 0, 0, 0.1);
		}

		.card:hover {
			box-shadow: 0px 30px 18px -8px rgba(0, 0, 0, 0.1);
			transform: scale(1.10, 1.10);
		}

		.card__info {
			z-index: 2;
			background-color: #fff;
			border-bottom-left-radius: 12px;
			border-bottom-right-radius: 12px;
			padding: 16px 24px 24px 24px;
		}

		.card__category {
			font-family: 'Raleway', sans-serif;
			text-transform: uppercase;
			font-size: 13px;
			letter-spacing: 2px;
			font-weight: 500;
			color: #868686;
		}

		.card__title {
			margin-top: 5px;
			margin-bottom: 10px;
			font-family: 'Roboto Slab', serif;
		}

		.card__by {
			font-size: 12px;
			font-family: 'Raleway', sans-serif;
			font-weight: 500;
		}

		.card__author {
			font-weight: 600;
			text-decoration: none;
			color: #AD7D52;
		}

		.card:hover .card__img--hover {
			height: 100%;
			opacity: 0.3;
		}

		.card:hover .card__info {
			background-color: transparent;
			position: relative;
		}

		.card:hover .card__info-hover {
			opacity: 1;
		}
	</style>

</head>

<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

	<section class="preloader">
		<div class="spinner">
			<span class="spinner-rotate"></span>
		</div>
	</section>


	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-5">
					<p>Welcome. Explore with LOVE</p>
				</div>
				<div class="col-md-8 col-sm-7 text-align-right">
					<span class="phone-icon"><i class="fa fa-phone"></i> 0704-724790</span>
					<span class="date-icon"><i class="fa fa-calendar-plus-o"></i> 6:00 AM - 10:00 PM (Mon-Fri)</span>
					<span class="email-icon"><i class="fa fa-envelope-o"></i> <a href="#">mathewkeyruri@gmail.com</a></span>
				</div>
			</div>
		</div>
	</header>


	<section class="navbar navbar-default navbar-static-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="icon icon-bar"></span>
					<span class="icon icon-bar"></span>
					<span class="icon icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand"><span class="icons">KENYATTA NATIONAL</span>Hospital</a>
			</div>
			<div class="collapse navbar-collapse">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#top" class="smoothScroll">Home</a></li>
					<li><a href="#about" class="smoothScroll">About Us</a></li>
					<li><a href="#doctors" class="smoothScroll">Doctors</a></li>
					<li class="appointment-btn"><a href="#appointment">Login</a></li>
<!--                    <li class="appointment-btn"><a href="Donation/login.php"> Atendant Login</a></li>-->
				</ul>
			</div>
		</div>
	</section>


	<section id="home" class="slider" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row">
				<div class="owl-carousel owl-theme">
					<div class="item item-first">
						<div class="caption">
							<div class="col-md-offset-1 col-md-10">
								<h3>Blood is meant to circulate.</h3>
								<h1>Pass it Around.</h1>
								<a href="#team" class="section-btn btn btn-default smoothScroll">Meet Our Doctors</a>
							</div>
						</div>
					</div>

					<div class="item item-second">
						<div class="caption">
							<div class="col-md-offset-1 col-md-10">
								<h3>You dont have to be a doctor to save a life.</h3>
								<h1>Just Donate Blood.</h1>
								<a href="#about" class="section-btn btn btn-default btn-gray smoothScroll">More About Us</a>
							</div>
						</div>
					</div>

					<div class="item item-third">
						<div class="caption">
							<div class="col-md-offset-1 col-md-10">
								<h3>Save a life.</h3>
								<h1>Give Blood.</h1>
								<a href="#news" class="section-btn btn btn-default btn-blue smoothScroll">Read Stories</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="about">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="about-info">
						<h2 class="wow fadeInUp" data-wow-delay="0.6s">Welcome to Kenyatta National Hospital Blood Donation System.</h2>
						<div class="wow fadeInUp" data-wow-delay="0.8s">
							<p>"This is a gift anyone can give. It has no cost and it can be tremendously powerful."</p>
							<p>"To The Young And Healthy It's No Lose. To Sick It's Hope Of Life. DONATE BLOOD To Give Back Life."</p>
						</div>
						<figure class="profile wow fadeInUp" data-wow-delay="1s">
							<img src="images/Mathew.jpg" class="img-responsive" alt="">
							<figcaption>
								<h3>Dr. Mathew Mwangi.</h3>
								<p>Managing Director</p>
							</figcaption>
						</figure>
					</div>
				</div>
			</div>
		</div>
		<br> <br>
		<div class="container" id="doctors">
			<center>
				<h2 class="wow fadeInUp" data-wow-delay="0.6s">Meet Our Doctors.</h2>
			</center>
			<center>
				<div class="wow fadeInUp" data-wow-delay="1.0s">
					<section class="cards">
						<article class="card card--1">
							<div class="card__img"></div>
							<a href="#" class="card_link">
								<div class="card__img--hover"></div>
							</a>
							<div class="card__info">
								<span class="card__category">Doctor</span>
								<h3 class="card__title">Billy Okeyo</h3>
							</div>
						</article>


						<article class="card card--2">
							<div class="card__img"></div>
							<a href="#" class="card_link">
								<div class="card__img--hover"></div>
							</a>
							<div class="card__info">
								<span class="card__category"> Doctor</span>
								<h3 class="card__title"> Mathew Mwangi</h3>
							</div>
						</article>

						<article class="card card--3">
							<div class="card__img"></div>
							<a href="#" class="card_link">
								<div class="card__img--hover"></div>
							</a>
							<div class="card__info">
								<span class="card__category"> Doctor</span>
								<h3 class="card__title">Fatma Ibrahim</h3>
							</div>
						</article>

						<article class="card card--4">
							<div class="card__img"></div>
							<a href="#" class="card_link">
								<div class="card__img--hover"></div>
							</a>
							<div class="card__info">
								<span class="card__category"> Doctor</span>
								<h3 class="card__title">Serena Muriuki</h3>
							</div>
						</article>

						<article class="card card--5">
							<div class="card__img"></div>
							<a href="#" class="card_link">
								<div class="card__img--hover"></div>
							</a>
							<div class="card__info">
								<span class="card__category"> Doctor</span>
								<h3 class="card__title">Kelvin Mbugua</h3>
							</div>
						</article>
					</section>
				</div>
			</center>
		</div>
	</section>


	<section id="appointment" data-stellar-background-ratio="3" style="background-color: rgba(179, 177, 177, 0.719); padding-bottom: 50px;">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<img src="images/a.jpg" class="img-responsive" alt="">
				</div>
				<div class="col-md-6 col-sm-6">
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#menu1">Donor Login</a></li>

						<li><a data-toggle="tab" href="#menu2">REGISTER</a></li>
					</ul>
					<div class="tab-content">
						<div id="menu1" class="tab-pane fade in active">
							<form id="appointment-form" role="form" method="post" action="#">
								<div class="section-title wow fadeInUp" data-wow-delay="0.4s">
									<h2 style="padding-top:40px; padding-bottom:20px;">Login</h2>
								</div>
								<div class="wow fadeInUp" data-wow-delay="0.8s">
									<div class="col-md-6 col-sm-6">
										<label for="email">Email</label>
										<input type="email" class="form-control" id="email" name="email" placeholder="Your Email" autocomplete="off">
									</div>
									<div class="col-md-6 col-sm-6">
										<label for="password">Password</label>
										<input type="password" class="form-control" id="password" name="password" placeholder="Your Password" autocomplete="off">
									</div>


									<div class="col-md-12 col-sm-12">
										<button type="submit" class="form-control" id="cf-submit" name="submit1">Login</button>
									</div>


								</div>
							</form>
						</div>


						<div id="menu2" class="tab-pane fade in">
							<form id="registration_form" role="form" method="post" action="">
								<div class="section-title wow fadeInUp" data-wow-delay="0.4s">
									<h2 style="padding-top:20px;">SignUp Now.</h2>
								</div>
								<div class="wow fadeInUp" data-wow-delay="0.8s">
									<div>
										<div class="col-md-6 col-sm-6">
											<label for="form_name"> Full Name</label>
											<input required type="text" class="form-control" id="form_fname" name="name" placeholder="Full Name" autocomplete="off"></br>
											<span class="error_form" id="fname_error_message" style="display:inline-block;"></span>

										</div>
										<div class="col-md-6 col-sm-6">
											<label for="form_email"> Email </label>
											<input type="email" required class="form-control" id="form_email" name="email" placeholder="Your Email" autocomplete="off"></br>
											<span class="error_form" id="email_error_message" style="display:inline-block;"></span>
										</div>
									</div>

									<div>
										<div class="col-md-6 col-sm-6">
											<label for="gender"> Gender </label>
											<select id="gender" name="gender" value="" class="form-control">
												<option value="male">Male</option>
												<option value="female">Female</option>
												<option value="other">Other</option>
											</select>
										</div>

										<div class="col-md-6 col-sm-6">
											<label for="date">DOB</label>
											<input type="date" id="date" name="dob" value="" class="form-control">
										</div>
									</div>

									<div class="col-md-6 col-sm-6">
										<label for="form_password"> Password </label>
										<input type="password" required class="form-control" id="form_password" name="password" placeholder="Password" autocomplete="off">
										<span class="error_form" id="password_error_message" style="display:inline-block;">
										</span>
									</div></label>

									<div class="col-md-6 col-sm-6">
										<label for="form_retype_password"> Confirm Password </label>
										<input type="password" required class="form-control" id="form_retype_password" name="confirmpassword" placeholder="Confirm Password" autocomplete="off">
										<span class="error_form" id="retype_password_error_message" style="display:inline-block;"></span>
									</div>

									<input type="hidden" name="role" value="1">
									<button type="submit" class="form-control" id="cf-submit" name="submit">Register</button>

								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>


	<footer data-stellar-background-ratio="5">
		<div class="container">
			<div class="row">

				<div class="col-md-4 col-sm-4">
					<div class="footer-thumb">
						<h4 class="wow fadeInUp" data-wow-delay="0.4s">Contact Info</h4>
						<p>We open everyday even during emergency times except for Sundays. Don't hesitate to contact us.</p>
						<div class="contact-info">
							<p><i class="fa fa-phone"></i> +254 704724790</p>
							<p><i class="fa fa-envelope-o"></i> <a href="#">mathewkeyruri@gmail.com</a></p>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-4">
					<div class="footer-thumb">
						<div class="opening-hours">
							<h4 class="wow fadeInUp" data-wow-delay="0.4s">Opening Hours</h4>
							<p>Monday - Friday <span>06:00 AM - 10:00 PM</span></p>
							<p>Saturday <span>09:00 AM - 08:00 PM</span></p>
							<p>Sunday <span>Closed</span></p>
						</div>
						<ul class="social-icon">
							<li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
							<li><a href="#" class="fa fa-twitter"></a></li>
							<li><a href="#" class="fa fa-instagram"></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-12 col-sm-12 border-top">
					<div class="col-md-4 col-sm-6">
						<div class="copyright-text">

						</div>

						<div class="col-md-2 col-sm-2 text-align-center">
							<div class="angle-up-btn" style="padding-left: 1000px;">
								<a href="#top" class="smoothScroll wow fadeInUp" data-wow-delay="1.2s"><i class="fa fa-angle-up"></i></a>
							</div>
						</div>
					</div>

				</div>
			</div>
	</footer>


	<script type="text/javascript">
		$(function() {

			$("#fname_error_message").hide();
			$("#email_error_message").hide();
			$("#password_error_message").hide();
			$("#retype_password_error_message").hide();

			var error_fname = false;
			var error_email = false;
			var error_password = false;
			var error_retype_password = false;

			$("#form_fname").focusout(function() {
				check_fname();
			});
			$("#form_email").focusout(function() {
				check_email();
			});
			$("#form_password").focusout(function() {
				check_password();
			});
			$("#form_retype_password").focusout(function() {
				check_retype_password();
			});

			function check_fname() {
				var pattern = /^[a-zA-Z ]*$/;
				var fname = $("#form_fname").val();
				if (pattern.test(fname) && fname !== '') {
					$("#fname_error_message").hide();
					$("#form_fname").css("border-bottom", "2px solid #34F458");
				} else {
					$("#fname_error_message").html("Should contain only Characters");
					$("#fname_error_message").show();
					$("#form_fname").css("border-bottom", "2px solid #F90A0A");
					error_fname = true;
				}
			}


			function check_password() {
				var password_length = $("#form_password").val().length;
				if (password_length < 8) {
					$("#password_error_message").html("Atleast 8 Characters");
					$("#password_error_message").show();
					$("#form_password").css("border-bottom", "2px solid #F90A0A");
					error_password = true;
				} else {
					$("#password_error_message").hide();
					$("#form_password").css("border-bottom", "2px solid #34F458");
				}
			}

			function check_retype_password() {
				var password = $("#form_password").val();
				var retype_password = $("#form_retype_password").val();
				if (password !== retype_password) {
					$("#retype_password_error_message").html("Passwords Did not Matched");
					$("#retype_password_error_message").show();
					$("#form_retype_password").css("border-bottom", "2px solid #F90A0A");
					error_retype_password = true;
				} else {
					$("#retype_password_error_message").hide();
					$("#form_retype_password").css("border-bottom", "2px solid #34F458");
				}
			}

			function check_email() {
				var pattern = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
				var email = $("#form_email").val();
				if (pattern.test(email) && email !== '') {
					$("#email_error_message").hide();
					$("#form_email").css("border-bottom", "2px solid #34F458");
				} else {
					$("#email_error_message").html("Invalid Email");
					$("#email_error_message").show();
					$("#form_email").css("border-bottom", "2px solid #F90A0A");
					error_email = true;
				}
			}

			$("#registration_form").submit(function() {
				error_fname = false;
				error_email = false;
				error_password = false;
				error_retype_password = false;

				check_fname();
				check_email();
				check_password();
				check_retype_password();

				if (error_fname === false && error_email === false && error_password === false && error_retype_password === false) {
					alert("Registration Successfull");
					return true;
				} else {
					alert("Please Fill the form Correctly");
					return false;
				}


			});
		});
	</script>


	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/custom.js"></script>

</body>

</html>