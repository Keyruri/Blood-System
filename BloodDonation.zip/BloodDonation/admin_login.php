<?php
ob_start();
session_start();
?>

<?
// error_reporting(E_ALL);
// ini_set("display_errors", 1);
?>

<html lang="en">

<head>
    <title>Admin Login</title>
    <link href="css/bootstrap1.min.css" rel="stylesheet">

</head>

<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-5">
        <h3>Admin Login</h3>
        <div class="container form-signin">

            <?php
            $msg = '';

            if (isset($_POST['login']) && !empty($_POST['username'])
                && !empty($_POST['password'])) {

                if ($_POST['username'] == 'root' &&
                    $_POST['password'] == '1234') {
                    $_SESSION['valid'] = true;
                    $_SESSION['timeout'] = time();
                    $_SESSION['username'] = 'root';

//                    header("Location: http://localhost/BloodDonation/admin/admindashboard.php");
                    header("Location:admin/admindashboard.php");
                } else {
echo "<script>alert('Wrong credentials') </script>";
                }
            }
            ?>
        </div> <!-- /container -->


        <form class="shadow-sm" role="form"
              action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);
              ?>" method="post">
            <h4 class="form-signin-heading"><?php echo $msg; ?></h4>
            <label>UserName</label>
            <input type="text" class="form-control"
                   name="username"
                   required autofocus></br>
            <label>Password</label>
            <input type="password" class="form-control"
                   name="password"  required><br>
            <button class="btn  btn-secondary btn-block" type="submit"
                    name="login">Login
            </button>
        </form>


    </div>
</div>
</div>

</body>
</html>