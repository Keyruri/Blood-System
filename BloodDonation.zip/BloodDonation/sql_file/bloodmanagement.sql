-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 03, 2020 at 12:48 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `adddonor`
--

CREATE TABLE `adddonor` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `bloodtype` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adddonor`
--

INSERT INTO `adddonor` (`id`, `name`, `bloodtype`, `phone`, `location`, `lat`, `lng`) VALUES
(1, 'Billy', 'B+', '9876556', 'ktm', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `addpatient`
--

CREATE TABLE `addpatient` (
  `id` int(20) NOT NULL,
  `image` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `bloodtype` varchar(20) NOT NULL,
  `hospitalname` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addpatient`
--

INSERT INTO `addpatient` (`id`, `image`, `name`, `bloodtype`, `hospitalname`, `location`, `phone`) VALUES
(1, '28279537_16478938619', 'John Doe', 'A-', 'Kenyatta', 'Nairobi', '2134354');

-- --------------------------------------------------------

--
-- Table structure for table `addpatientdetail`
--

CREATE TABLE `addpatientdetail` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `bloodtype` varchar(20) NOT NULL,
  `age` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `hospitalname` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addpatientdetail`
--

INSERT INTO `addpatientdetail` (`id`, `name`, `bloodtype`, `age`, `phone`, `hospitalname`, `location`, `status`) VALUES
(3, 'Billy dan', 'A+', '21', '56436473', 'KNH', 'Thika', '1'),
(4, 'John Smith', 'A+', '22', '23525252', 'Mbagathi', 'Nairobi', '1'),
(5, 'Jane Doe', 'A+', '55', '129756353', 'Nairobi Hospital', 'Nairobi', '1'),
(15, 'John Doe', 'A+', '33', '6389373178', 'Child care', 'Kisumu', '');

-- --------------------------------------------------------

--
-- Table structure for table `makedonation`
--

CREATE TABLE `makedonation` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makedonation`
--

INSERT INTO `makedonation` (`id`, `name`, `email`, `location`) VALUES
(1, 'mahesh', '3456784567', 'balaju'),
(2, 'rame', '345678998765', 'balaju'),
(3, 'Billy Okeyo', '123456789', 'Utalii House');

-- --------------------------------------------------------

--
-- Table structure for table `makereservation`
--

CREATE TABLE `makereservation` (
  `id` int(4) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makereservation`
--

INSERT INTO `makereservation` (`id`, `name`, `phone`, `location`) VALUES
(7, 'Billy', '9849955377', 'Nairobi'),
(8, 'Serena', '9849955377', 'Thika'),
(9, 'Kelvin', 'jsjsjsj', 'Thika'),
(10, 'Mathew', '2345678', 'Thika'),
(11, 'Fatma', '123456', 'Nairobi');

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `bloodtype` varchar(20) NOT NULL,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `name`, `bloodtype`, `lat`, `lng`, `phone`) VALUES
(18, 'Utalii House', '123456789', -1.28288, 36.8165, 'A+'),
(19, 'Central Park', '987654321', -1.28581, 36.8168, 'B+'),
(20, 'Utalii House', '123456789', -1.28255, 36.8166, 'A+');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `date1` varchar(20) NOT NULL,
  `event` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `name`, `date1`, `event`, `location`, `status`, `date`) VALUES
(1, 'Change For blood', '2018-05-11', 'Change for blood', 'Kenyata Hospital', 'read', '2020-09-03'),
(2, 'Childs care', '2018-05-05', 'Mr. President as chi', 'Thika Level 5', 'read', '2020-06-22'),
(6, 'Donation Importance.', '2018-05-25', 'all is invited', 'Nairobi Hospital', 'read', '2020-07-11');

-- --------------------------------------------------------

--
-- Table structure for table `requestblood`
--

CREATE TABLE `requestblood` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `image` varchar(20) NOT NULL,
  `bloodtype` varchar(20) NOT NULL,
  `hospitalname` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestblood`
--

INSERT INTO `requestblood` (`id`, `name`, `image`, `bloodtype`, `hospitalname`, `location`) VALUES
(1, 'Billy', '', 'O+', 'manmohan', 'Nairobi'),
(2, 'Dan', 'Untitled.png', 'O-', 'manmohan', 'Juja'),
(3, 'Doe', 'Untitled.png', 'B+', 'Om hospital', 'K.Road');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `gender`, `email`, `password`, `dob`, `role`) VALUES
(19, 'Serena', 'female', 'serena@gmail.com', 'serenamuriuki', '2018-05-15', '1'),
(31, 'Mathew', 'male', 'mathew@gmail.com', 'mathewmwangi', '2018-05-14', '1'),
(32, 'Fatma', 'female', 'fatma@gmail.com', 'fatmaibrahim', '2018-05-14', '1'),
(33, 'Kelvin', 'male', 'kelvin@gmail.com', 'kelvinmbugua', '2018-05-16', '1'),
(34, 'Billy', 'male', 'billy@gmail.com', 'billy.dan', '2018-05-16', '1'),
(35, 'admin', 'male', 'admin@gmail.com', 'admin', '2018-05-15', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adddonor`
--
ALTER TABLE `adddonor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addpatient`
--
ALTER TABLE `addpatient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addpatientdetail`
--
ALTER TABLE `addpatientdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `makedonation`
--
ALTER TABLE `makedonation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `makereservation`
--
ALTER TABLE `makereservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requestblood`
--
ALTER TABLE `requestblood`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adddonor`
--
ALTER TABLE `adddonor`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `addpatient`
--
ALTER TABLE `addpatient`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `addpatientdetail`
--
ALTER TABLE `addpatientdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `makedonation`
--
ALTER TABLE `makedonation`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `makereservation`
--
ALTER TABLE `makereservation`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `requestblood`
--
ALTER TABLE `requestblood`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
