<?php
$con = mysqli_connect("localhost", "root", "", "bloodmanagement") or die(mysqli_connect_error());
