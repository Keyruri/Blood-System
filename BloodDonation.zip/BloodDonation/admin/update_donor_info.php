<?php
if (isset($_REQUEST["id"])) {
    $id = $_REQUEST["id"];

    $con = mysqli_connect("localhost", "root", "", "bloodmanagement") or die(mysqli_connect_error());


    $sql = "SELECT *  FROM donor_information WHERE id = $id ";

    $result = mysqli_query($con, $sql) or die(mysqli_error($con));
    if (mysqli_num_rows($result) == 0){
        header('location:update_donor_info.php');
    }
    $user = mysqli_fetch_assoc($result);
//var_dump($user);

}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Form</title>
    <link rel="stylesheet" href="css/bootstrap1.min.css">
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-sm-5">
            <form action="save-update.php" method="post">
                <h3>You can only update the provided fields</h3>
                <input type="hidden" name="id" value="<?=$user['id']?>">
                <div class="form-group">
                    <label>Donor Number</label>
                    <input type="text" name="donor_number" value="<?=$user['donor_number']?>" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" value="<?=$user['location']?>" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Blood Group</label>
                    <input type="text" name="blood_group" value="<?=$user['blood_group']?>" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?=$user['email']?>" class="form-control" required>
                </div>
                <button class="btn btn-secondary btn-block">Update</button>
            </form>
        </div>
    </div>
</div>



</body>
</html>

