<?php
$con = mysqli_connect("localhost", "root", "", "bloodmanagement") or die(mysqli_connect_error());


$sql = "SELECT* FROM donor_information";

$result = mysqli_query($con, $sql) or die(mysqli_error($con));// executing the query
$rows = mysqli_fetch_all($result, 1);
mysqli_close($con);//close the connection
//var_dump($rows[0]);
//foreach ($rows as $user)
//{
//    echo $user['email'];
//    echo "<hr>";
//}
//echo json_encode($rows);

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap1.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
</head>
<body>

<div >
    <div class="row-sm-12">
<table id="example" class="table table-striped">
    <thead>
    <tr>
        <th>ID</th>
        <th>Email</th>
        <th>Blood Group</th>
        <th>Consent</th>
        <th>Location</th>
        <!--                    <th>Accept</th>-->

        <th>Donation Rate</th>
        <th>Date</th>
        <th>Problem</th>
        <th>ID.NO</th>

        <th>DOB</th>
        <th>Gender</th>

        <!--                    <th>Parent NUmber</th>-->
        <!--                    <th>Donor Number</th>-->


        <th>Hospital</th>
        <th>precondition</th>

        <!--                    <th>Delete</th>-->
        <!--                    <th>Update</th>-->
    </tr>
    </thead>
    <tbody>
    <?php foreach ($rows as $user): ?>
        <tr>
            <td><?= $user["id"] ?></td>
            <td><?= $user["email"] ?></td>
            <td><?= $user["blood_group"] ?></td>
            <td><?= $user["concent"] ?></td>
            <td><?= $user["location"] ?></td>
            <td><?= $user["donation_time"] ?></td>
            <td><?= $user["date"] ?></td>
            <td><?= $user["problem"] ?></td>
            <td><?= $user["id_number"] ?></td>

            <td><?= $user["dob"] ?></td>
            <td><?= $user["gender"] ?></td>

            <!--                        <td>--><?//= $user["parent_number"] ?><!--</td>-->
            <!--                        <td>--><?//= $user["donor_number"] ?><!--</td>-->


            <td><?= $user["hospital"] ?></td>
            <td><?= $user["precondition"] ?></td>
            <!--                        <td>--><?//= $user["accept"] ?><!--</td>-->
            <td><a class="btn btn-danger btn-sm" href="delet_donor_info.php?id=<?= $user['id'] ?>">Delete</a></td>
            <td><a class="btn btn-dark btn-sm " href="update_donor_info.php?id=<?= $user['id'] ?>">Update</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
</script>

</body>
</html>