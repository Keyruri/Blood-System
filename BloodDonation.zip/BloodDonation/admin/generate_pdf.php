<?php

require_once("config.php");
//require('fpdf/fpdf.php');
require('pdf_mc_table.php');
$pdf = new PDF_MC_Table();
$pdf->AddPage();


// code for print Heading of tables
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetWidths(array(10, 40, 40, 40, 40, 40, 40, 40));
$ret = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='bloodmanagement' AND `TABLE_NAME`='addpatientdetail'";
$query1 = $dbh->prepare($ret);
$query1->execute();
$header = $query1->fetchAll(PDO::FETCH_OBJ);
$cnt = 1;
if ($query1->rowCount() > 0) {
    foreach ($header as $heading) {
        foreach ($heading as $column_heading)
            $pdf->Cell(46, 12, $column_heading, 1);
        $pdf->SetWidths(array(10, 40, 40, 40, 40, 40, 40, 40));
    }
}
//code for print data
$sql = "SELECT * from  addpatientdetail";
$query = $dbh->prepare($sql);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);
$cnt = 1;
if ($query->rowCount() > 0) {
    foreach ($results as $row) {
        $pdf->SetWidths(array(10, 40, 40, 40, 40, 40, 40, 40));
        $pdf->SetFont('Arial', '', 12);
        $pdf->Ln();
        foreach ($row as $column)
            $pdf->Cell(46, 12, $column, 1);
    }
}
$pdf->Output();
