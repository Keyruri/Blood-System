<?php
if (isset($_REQUEST["id"]))
{
    $id = $_REQUEST["id"];

 $con = mysqli_connect("localhost", "root", "", "bloodmanagement") or die(mysqli_connect_error());


    $sql = "DELETE  FROM donor_information WHERE id = $id ";

    mysqli_query($con, $sql) or die(mysqli_error($con));
    setcookie('message', "The user has been deleted successfully", time()+3);

}
//Redirect
header("location:admindashboard.php");