<?php
if (isset($_POST["id"]))
{
    $id = $_POST["id"];
    $donor_number =$_POST['donor_number'];
    $location = $_POST['location'];
    $blood_group = $_POST['blood_group'];
    $email = $_POST['email'];
    $con = mysqli_connect("localhost", "root", "", "bloodmanagement") or die(mysqli_connect_error());


    $sql = "UPDATE  donor_information SET donor_number  = '$donor_number', location = '$location',location  = '$location',blood_group  = '$blood_group',email  = '$email' WHERE id=$id ";

    mysqli_query($con, $sql) or die(mysqli_error($con));
    setcookie('message', "The user $email has been updated successfully", time()+3);
}
header('read_donor.php');